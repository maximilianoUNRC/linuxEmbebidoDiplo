var indexSectionsWithContent =
{
  0: "abcdefghilmprstuw~",
  1: "agipsu",
  2: "m",
  3: "acgipstu",
  4: "abcdefghilmprstuw~",
  5: "m",
  6: "deimprs",
  7: "bdeimprsu",
  8: "bcdfgilmprt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};

